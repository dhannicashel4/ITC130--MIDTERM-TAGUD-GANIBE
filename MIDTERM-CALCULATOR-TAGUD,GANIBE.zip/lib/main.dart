import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Calculator',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  String _display = '';

  void _onButtonPressed(String buttonText) {
    setState(() {
      if (buttonText == '=') {
        _display = eval(_display);
      } else if (buttonText == 'C') {
        _display = '';
      } else {
        _display += buttonText;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Calculator'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              _display,
              style: TextStyle(fontSize: 24),
            ),
            SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                _buildButton('7'),
                _buildButton('8'),
                _buildButton('9'),
                _buildButton('÷'), // Division
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                _buildButton('4'),
                _buildButton('5'),
                _buildButton('6'),
                _buildButton('×'), // Multiplication
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                _buildButton('1'),
                _buildButton('2'),
                _buildButton('3'),
                _buildButton('-'), // Subtraction
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                _buildButton('C'), // Clear
                _buildButton('0'),
                _buildButton('='), // Equals
                _buildButton('+'), // Addition
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildButton(String buttonText) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: ElevatedButton(
        onPressed: () {
          _onButtonPressed(buttonText);
        },
        child: Text(
          buttonText,
          style: TextStyle(fontSize: 20),
        ),
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color.fromARGB(255, 219, 33, 243),
          foregroundColor: Color.fromARGB(255, 150, 97, 0),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18.0),
            side: BorderSide(color: Colors.blue),
          ),
        ),
      ),
    );
  }

  // Evaluation function
  String eval(String expression) {
    try {
      final tokens = TokenStream(expression).tokenize();
      return evalExpression(tokens).toString();
    } catch (e) {
      return 'Error';
    }
  }

  dynamic evalExpression(List<String> tokens) {
    final stream = TokenStream.fromTokens(tokens);
    return evalLoop(stream);
  }

  dynamic evalLoop(TokenStream stream) {
    dynamic result = evalTerm(stream);
    while (stream.hasNext) {
      final token = stream.next();
      if (token == '+') {
        result += evalTerm(stream);
      } else if (token == '-') {
        result -= evalTerm(stream);
      } else {
        throw ArgumentError('Invalid operator: $token');
      }
    }
    return result;
  }

  dynamic evalTerm(TokenStream stream) {
    dynamic result = evalFactor(stream);
    while (stream.hasNext) {
      final token = stream.next();
      if (token == '×') {
        result *= evalFactor(stream);
      } else if (token == '÷') {
        result /= evalFactor(stream);
      } else {
        stream.back();
        break;
      }
    }
    return result;
  }

  dynamic evalFactor(TokenStream stream) {
    final token = stream.next();
    if (token == '(') {
      final result = evalExpression(stream.tokens);
      if (stream.next() != ')') {
        throw ArgumentError('Expected closing parenthesis');
      }
      return result;
    } else {
      return double.parse(token);
    }
  }
}

class TokenStream {
  final String expression;
  int position = 0;
  List<String> tokens;

  TokenStream(this.expression) : tokens = [];

  TokenStream.fromTokens(this.tokens) : expression = '';

  bool get hasNext => position < tokens.length;

  String next() {
    return tokens[position++];
  }

  void back() {
    position--;
  }

  List<String> tokenize() {
    final buffer = StringBuffer();
    for (var char in expression.split('')) {
      if (_isOperator(char) || _isParenthesis(char)) {
        if (buffer.isNotEmpty) {
          tokens.add(buffer.toString());
          buffer.clear();
        }
        tokens.add(char);
      } else if (_isWhitespace(char)) {
        if (buffer.isNotEmpty) {
          tokens.add(buffer.toString());
          buffer.clear();
        }
      } else {
        buffer.write(char);
      }
    }
    if (buffer.isNotEmpty) {
      tokens.add(buffer.toString());
    }
    return tokens;
  }

  bool _isOperator(String char) {
    return '+-×÷'.contains(char);
  }

  bool _isParenthesis(String char) {
    return '()'.contains(char);
  }

  bool _isWhitespace(String char) {
    return RegExp(r'\s').hasMatch(char);
  }
}
